<?php
if(isset($_POST['save_audio'])&& $_POST['save_audio']=="Upload Music")
{
	$dir='assest/';
	$audio_path=$dir.basename($_FILES['musicFile']['name']);
	if(move_uploaded_file($_FILES['musicFile']['tmp_name'], $audio_path))
	{
		echo "Upload Successfull";
	}
	echo "WOrking";
}